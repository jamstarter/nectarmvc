<?php
namespace userauth\models;
use system\Model as NectarModel;

class SampleModel extends NectarModel{

	function getName(){
		return 'World';
	}
}